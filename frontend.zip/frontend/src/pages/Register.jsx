import React from 'react';
import RegisterComponent from '../components/Register';

function Register() {
  return (
    <div className="container mx-auto px-4 py-8">
      <RegisterComponent />
    </div>
  );
}

export default Register;