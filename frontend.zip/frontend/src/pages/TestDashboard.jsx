import React from 'react';

const TestDashboard = () => {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Dashboard Test Page</h1>
      <p>If you can see this, the route is working correctly.</p>
    </div>
  );
};

export default TestDashboard; 